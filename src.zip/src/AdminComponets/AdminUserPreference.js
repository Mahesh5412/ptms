import React from "react";
import { Text, TouchableOpacity, View,TextInput } from "react-native";


export default class AdminUserPreference extends React.Component{

 render(){

    return(
        <View>

            <TouchableOpacity>

            <Text>AdminUserPreference</Text>
            </TouchableOpacity>
        </View>
    );

 }

}
/*
FileName:UserPendingManageTask.js
Version:1.0.0
Purpose:Getting the List of user pending manage tasks list 
Devloper:Rishitha,Harsha,Mahesh,Santosh
*/

import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, TextInput, Dimensions, TouchableOpacity, FlatList, Image } from 'react-native';
import { Icon, Left, Button, Container, Header, Content, Item, Input } from 'native-base';
import AsyncStorage from '@react-native-community/async-storage';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import Modal from "react-native-simple-modal";
import SearchableDropdown from 'react-native-searchable-dropdown';
import { Collapse, CollapseHeader, CollapseBody } from "accordion-collapse-react-native";
import {API }from "../WebServices/RestClient";
import NetInfo from '@react-native-community/netinfo';
import Snackbar from 'react-native-snackbar';

class ListItem extends React.Component {
  render() {
    const { item } = this.props;
    return (
      <View>
        <Collapse style={styles.container}>

          <CollapseHeader style={styles.boxheader}>

            <View style={{ flexDirection: 'row' }}>
              <Text style={styles.signUpText0} >TASK ID:</Text>
              <Text style={styles.signUpText1} >{item.taskid}</Text>
              {/* <Text style={styles.signUpText1} >{item.date}</Text> */}
            </View>
            <Text style={styles.signUpText2} >{item.date}</Text>




            <View style={{ flexDirection: 'row', paddingRight: 25, }}>
              <Text style={styles.signUpText4} >Project Title:</Text>
              <Text style={styles.signUpText3} >{item.projectitle}</Text>
            </View>


            <View style={styles.box1}>

              <View style={{ flexDirection: 'row' }}>
                <Text style={styles.signUpText00} >Task Title:</Text>
                <Text style={styles.signUpText11} >{item.tasktitle}</Text>
                {/* <Text style={styles.signUpText1} >{item.date}</Text> */}
              </View>
              <Text style={styles.signUpText02} >Pending </Text>


            </View>
          </CollapseHeader>

          <CollapseBody>


            <View style={{ flexDirection: 'row', paddingRight: 35, }}>
              <Text style={styles.signUpText44} >Description</Text>
              <Text style={styles.signUpText33} >{item.taskdescription}</Text>
              {/* <Text style={styles.signUpText33} >{item.recipeNames}</Text> */}
            </View>


            <View style={styles.box1}>

              <View style={{ flexDirection: 'row', paddingRight: 35, }}>
                <Text style={styles.signUpText000} >Target Time:</Text>
                <Text style={styles.signUpText111} >{item.targettime}</Text>
                {/* <Text style={styles.signUpText1} >Task Status:0% completed</Text>  */}
              </View>
              <View styles={{ paddingRight: 40 }}>
                <Text style={styles.signUpText111} >Task Status:0% completed </Text>
              </View>

            </View>
            <View style={styles.box1}>

              <View style={{ flexDirection: 'row' }}>
                <Text style={styles.signUpText000} >Assigned To:</Text>
                <Text style={styles.signUpText111} >{item.assigntto}</Text>
                {/* <Text style={styles.signUpText1} >{item.date}</Text> */}
              </View>
              <Text style={styles.signUpText002} >Assigned By:Rishitha </Text>


            </View>

            <View style={{ flexDirection: 'row', paddingRight: 25, }}>
              <Text style={styles.signUpText44} >Assigned On:</Text>
              <Text style={styles.signUpText33} >{item.assignedon}</Text>
              {/* <Text style={styles.signUpText33} >{item.recipeNames}</Text> */}
            </View>


            <View style={styles.box1}>

              <View style={{ flexDirection: 'row', width: wp('50%'), paddingRight: 50, }}>
                <Text style={styles.signUpText000} >Time Left:</Text>
                <Text style={styles.signUpText111} >{item.timeLeft}</Text>
                {/* <Text style={styles.signUpText1} >{item.date}</Text> */}
              </View>
              <Text style={styles.signUpText000} >Updated On:{item.taskEndDate} </Text>

            </View>

            <View style={{ flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center' }}>
              <TouchableOpacity style={{ width: 60, backgroundColor: 'red' }}><Text style={{ color: '#fff', textAlign: 'center' }}>DELETE</Text></TouchableOpacity>
              <TouchableOpacity style={{ width: 100, backgroundColor: '#97f362', marginLeft: 10, }} onPress={() => this.props.openModal()}><Text style={{ color: '#fff', textAlign: 'center' }}>Add Sub Task</Text></TouchableOpacity>
              <TouchableOpacity style={{ width: 120, backgroundColor: '#6cbb3f', marginLeft: 10, }} onPress={()=>this.props.Module()}>
              <Text style={{ color: '#fff', textAlign: 'center' }}>VIEW SUB TASK</Text></TouchableOpacity>
              <TouchableOpacity onPress={this.props.ModifyMaintask} style={{ width: 60, backgroundColor: 'black', marginLeft: 10, }}><Text style={{ color: '#fff', textAlign: 'center', }}>MODIFY</Text></TouchableOpacity>
            </View>


          </CollapseBody>
        </Collapse>
      </View>
    )
  }
}


export default class Pending extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: true,
      dataSource: [],
      isFetching: false,
      open: false,
      ProjectTitle: "",
      ProjectDescription: "",
      role: '',
      userToken: '',
      empData: [],
      dependencyData: [],
      subTask: '',
      description: '',
      days: '',
      time: '',
      modifyTask: 'modify',
      dependencyid: 'NA',
    };
    this.arrayholder = [] ;
  }


  modalDidOpen = () => {
    AsyncStorage.getItem("role", (err, res) => {
      this.setState({ role: res });

    });
    AsyncStorage.getItem("userToken", (err, res) => {
      this.setState({ userToken: res });

    });

  }
  modalDidClose = () => {

    this.setState({ open: false });

  };

  moveUp = () => this.setState({ offset: -1200 });

  resetPosition = () => this.setState({ offset: 0 });

  openModal = (item, index) => {
    console.log(item);
    console.log(index);
    console.log(item.taskid);
    this.setState({ item: item });
    this.setState({ open: true });
  }



  closeModal = () => this.setState({ open: false });


  componentDidMount() {

    this.UserPendingManagetasks();
    this.empSearch();
    this.dependencySearch();
  }

  //to refresh the pending manage tasks list 
  onRefresh() {
    this.setState({ isFetching: true }, function () { this.UserPendingManagetasks() });
  }



  componentWillReceiveProps(nextProps) {
    console.log(nextProps);
    console.log("re loading...........")
    this.UserPendingManagetasks();
  }

  //UserPendingManagetasks Getting
  UserPendingManagetasks() {

    AsyncStorage.getItem("cropcode", (err, res) => {
      const cropcode = res;

      AsyncStorage.getItem("empId", (err, res) => {
        const empId = res;


        AsyncStorage.getItem("emp_role", (err, res) => {
          const emp_role = res;

          NetInfo.fetch().then(state => {
            if (state.type == "none") {
              console.log(state.type);
              Snackbar.show({
                title: 'No Internet Connection',
                backgroundColor: 'red',
                duration: Snackbar.LENGTH_LONG,
              });
            }else{

          fetch(API+'getmanagemaintasks.php',
            {
              method: 'POST',
              headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                crop: cropcode,
                action: "pending",
                userType: emp_role,
                empId: empId
              })
            })
            .then((response) => response.json())
            .then((responseJson) => {
              console.log(responseJson);
              console.log(JSON.stringify(responseJson))
              this.setState({
                isLoading: false,
                dataSource: responseJson.data,
                isFetching: false
              }, function () {
              });
              this.arrayholder = responseJson.data ;
            })
            .catch((error) => {
              console.error(error);
            });
          }
        });
        });

      });

    });
  }
  //Modify Maintask
  ModifyMaintask(item, index) {

    const { modifyTask } = this.state;
    console.log("mid" + item.taskid + "id" + item.ideano);

    this.props.navigation.navigate("AddTask", { maintaskid: item.taskid, IdeaId: item.ideano, modifyTask: modifyTask });

  }
  addSubTask = () => {

    const { person, item, dependency, subTask, description, days, time, } = this.state;
    console.log(person);
    console.log(dependency);
    console.log(subTask);
    console.log(item);
    console.log(item.taskid);


    let EstHours = Number(days * 24) + Number(time);
    // alert(Number(days) + "  " + Number(time));
   // alert(person);
    AsyncStorage.getItem("empId", (err, res) => {
      const empId = res;
      AsyncStorage.getItem("cropcode", (err, res) => {
        const cropcode = res;
        NetInfo.fetch().then(state => {
          if (state.type == "none") {
            console.log(state.type);
            Snackbar.show({
              title: 'No Internet Connection',
              backgroundColor: 'red',
              duration: Snackbar.LENGTH_LONG,
            });
          }else{
        fetch(API+'managesubtasks.php', {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({

            title: subTask,
            description: description,
            days: days,
            EstimatedHours: EstHours,
            assignedBy: empId,
            assignedTo: person,
            dependencyId: this.state.dependencyid,
            action: "add",
            days: this.state.days,
            hours: this.state.time,
            maintaskId: item.taskid,
            moduleId: item.moduleId,
            empId: empId,
            crop: cropcode,

          })
        }).then((response) => response.json())
          .then((responseJson) => {
            console.log(JSON.stringify(responseJson));
            console.log(responseJson);
            if (responseJson.status === 'True') {
              console.log("done")
              this.setState({ open: false })
            }
          }).catch((error) => {
            console.error(error);
          });
        }
      });
      });
    });
    this.closeModal();
  };

  //to get the all the employees list 
  empSearch() {
    AsyncStorage.getItem("cropcode", (err, res) => {
      const cropcode = res;
      NetInfo.fetch().then(state => {
        if (state.type == "none") {
          console.log(state.type);
          Snackbar.show({
            title: 'No Internet Connection',
            backgroundColor: 'red',
            duration: Snackbar.LENGTH_LONG,
          });
        }else{
      fetch(API+'getEmployees.php', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: "add",
          crop: cropcode,
        })
      })
        .then((response) => response.json())
        .then((responseJson) => {

          this.setState({
            empData: [...responseJson.data],
          });
        }
        )
        .catch((error) => {
          console.error(error);
        });
      }
    });
    });
  }

  dependencySearch() {
    AsyncStorage.getItem("cropcode", (err, res) => {
      const cropcode = res;
      NetInfo.fetch().then(state => {
        if (state.type == "none") {
          console.log(state.type);
          Snackbar.show({
            title: 'No Internet Connection',
            backgroundColor: 'red',
            duration: Snackbar.LENGTH_LONG,
          });
        }else{
      fetch(API+'get_subtasks.php', {
        
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          // proj_title: this.state.ProjectTitle,

          action: "setdependency",
          crop: cropcode, //Async
        })
      })
        .then((response) => response.json())
        .then((responseJson) => {

          this.setState({
            dependencyData: [...responseJson.data],
          });
          // AsyncStorage.setItem('userToken',responseJson.name);
        }
        )
        .catch((error) => {
          console.error(error);
        });
      }
    });
    });
  }

  FlatListItemSeparator = () => {
    return (
      <View
        style={{
          //  height: .5,
          width: "100%",
          backgroundColor: "red",
        }}
      />
    );
  }

  person(item) {
    console.log(item);
    this.setState({
      person: item.name
    });
  }

  dependency(item) {
    console.log(item);
    this.setState({
      dependency: item.name

    });

  }
  Module=(item,index)=>{

    console.log(item.taskid);
    console.log(index);
      this.props.navigation.navigate("ViewSubTasks",{taskId:item.taskid});
    
      }


  _listEmptyComponent = () => {
    return (
      <View>
        <Text></Text>

      </View>
    )
  }

  //to filter the search data in search area 
  SearchFilterFunction(text){
    console.log(text);
    const newData = this.arrayholder.filter(function(item){

        const taskid = item.taskid.toUpperCase()
        const taskid1 = text.toUpperCase()
     //   const date = item.date.toUpperCase()
       // const date1 = text.toUpperCase()
        const projectitle = item.projectitle.toUpperCase()
        const projectitle1 = text.toUpperCase()
        const tasktitle = item.tasktitle.toUpperCase()
        const tasktitle1 = text.toUpperCase()
        const taskdescription = item.taskdescription.toUpperCase()
        const taskdescription1 = text.toUpperCase()
        const targettime = item.targettime.toUpperCase()
        const targettime1 = text.toUpperCase()
        const assigntto = item.assigntto.toUpperCase()
        const assigntto1 = text.toUpperCase()
        const assignedon = item.assignedon.toUpperCase()
        const assignedon1 = text.toUpperCase()
        const timeLeft = item.timeLeft.toUpperCase()
        const timeLeft1 = text.toUpperCase()
        const taskEndDate = item.taskEndDate.toUpperCase()
        const taskEndDate1 = text.toUpperCase()
     
       
        return taskid.indexOf(taskid1) > -1 || 
      //  date.indexOf(date1) > -1 || 
        projectitle.indexOf(projectitle1) > -1 ||
        tasktitle.indexOf(tasktitle1) > -1 ||
        taskdescription.indexOf(taskdescription1) > -1 ||
        targettime.indexOf(targettime1) > -1 ||
        assigntto.indexOf(assigntto1) > -1 ||
        assignedon.indexOf(assignedon1) > -1 ||
        timeLeft.indexOf(timeLeft1) > -1 ||
        taskEndDate.indexOf(taskEndDate1) > -1 
      
    })
    this.setState({
        dataSource: newData,
        text: text
    })
}


  render() {
    return (
      <View style={styles.MainContainer}>
              <Item> 
     <Input placeholder="Search" 
      onChangeText={(text) => this.SearchFilterFunction(text)}/>
       <Icon name="search" />
     </Item>
        <View style={styles.end1}>
          <FlatList
            extraData={this.state}
            keyExtractor={this._keyExtractor}
            renderItem={this._renderItem}
            style={{ flex: 1, }}
            data={this.state.dataSource}
            onRefresh={() => this.onRefresh()}
            refreshing={this.state.isFetching}
            ItemSeparatorComponent={this.FlatListItemSeparator}
            renderItem={({ item, index }) =>
              <View style={styles.container2} >
                <ListItem navigation={this.props.navigation}
                  item={item}
                  openModal={() => this.openModal(item, index)}
                  ModifyMaintask={() => this.ModifyMaintask(item, index)}
                  Module={()=>this.Module(item,index)}
                />
              </View>
            }
            keyExtractor={item => item.id}
            ListEmptyComponent={this._listEmptyComponent}
          />
        </View>
        <Modal animationType="fade" transparent={true} visible={this.state.modalVisible}
          offset={this.state.offset}
          open={this.state.open}
          modalDidOpen={this.modalDidOpen}
          modalDidClose={this.modalDidClose}
          style={{ alignItems: "center", backgroundColor: 'white' }} >


          <View style={{ alignItems: "center", paddingBottom: 60, backgroundColor: 'white' }}>

            <View style={{ marginLeft: 10, width: '100%', backgroundColor: 'white' }}>
              <TextInput placeholder="Sub Task Title" style={{ width: '90%', borderBottomWidth: 0.5 }}
                onChangeText={(text) => this.setState({ subTask: text })}></TextInput>
              <TextInput placeholder="Description" style={{ width: '90%', borderBottomWidth: 0.5 }}
                onChangeText={(text) => this.setState({ description: text })}></TextInput>
            </View>

            <View style={{ marginLeft: 10, width: '100%', }}>
              <Text style={{ paddingTop: 10 }}>Estimated Time</Text>
              <View style={{ flexDirection: 'row', marginTop: 10 }}>
                <TextInput style={{ width: '20%', height: '80%', borderWidth: 0.2 }} onChangeText={(text) =>
                  this.setState({ days: text })}></TextInput>
                <Text style={{ paddingLeft: 10, paddingTop: 10 }}>Days</Text>
                <TextInput style={{ marginLeft: 10, width: '20%', height: '80%', borderWidth: 0.2 }}
                  onChangeText={(text) => this.setState({ time: text })}></TextInput>
                <Text style={{ paddingLeft: 10, paddingTop: 10 }}>Hours</Text>
              </View>
            </View>
            <Text style={{ paddingTop: 10 }}>Select Resources</Text>
            <SearchableDropdown
              onTextChange={text => console.log(text)}

              // onItemSelect={item =>item.name}
              onItemSelect={item => this.setState({ person: item.id })}

              containerStyle={{ padding: 5, color: 'black', }}

              textInputStyle={{
                color: 'black',
                padding: 12,
                borderWidth: 1,
                borderColor: '#ccc',
                // backgroundColor: '#FAF7F6',
                justifyContent: 'center',
                width: wp('85%'),
                // borderRadius:10,

              }}
              itemStyle={{

                padding: 10,
                marginTop: 2,
                // backgroundColor: '#FAF9F8',
                borderColor: '#bbb',
                borderWidth: 1,
                // borderRadius:10,

              }}
              itemTextStyle={{
                color: 'black',
              }}
              itemsContainerStyle={{
                maxHeight: '80%',
              }}
              items={this.state.empData}
              // defaultIndex={2}
              placeholder="          SELECT RESOURCE"

              underlineColorAndroid="transparent"
            />

            <Text style={{ paddingTop: 10 }}>Add Dependency</Text>

            <SearchableDropdown
              onTextChange={text => console.log(text)}

              // onItemSelect={item =>(JSON.stringify(item.name))}
              onItemSelect={(item) => { this.setState({ dependencyid: item.id }) }}

              containerStyle={{ padding: 5, color: 'black', }}

              textInputStyle={{
                color: 'black',
                padding: 12,
                borderWidth: 1,
                borderColor: '#ccc',
                // backgroundColor: '#FAF7F6',
                justifyContent: 'center',
                width: wp('85%'),
                // borderRadius:10,

              }}
              itemStyle={{

                padding: 10,
                marginTop: 2,
                // backgroundColor: '#FAF9F8',
                borderColor: '#bbb',
                borderWidth: 1,
                // borderRadius:10,

              }}
              itemTextStyle={{
                color: 'black',
              }}
              itemsContainerStyle={{
                maxHeight: '80%',
              }}
              items={this.state.dependencyData}
              //defaultIndex={2}
              // onPress={this.search()}
              placeholder="          ADD DEPENDENCY"

              underlineColorAndroid="transparent"
            />


            <View style={{ flexDirection: 'row', marginTop: 30 }}>
              <TouchableOpacity style={{
                margin: 5, backgroundColor: 'red', padding: 19, height: 30, alignItems:
                  "center", justifyContent: 'center'
              }} onPress={this.closeModal}>
                <Text style={{ color: 'white' }}>CANCEL</Text>
              </TouchableOpacity>
              <TouchableOpacity style={{
                margin: 5, backgroundColor: 'green', padding: 20, height: 30, alignItems:
                  "center", justifyContent: 'center'
              }} onPress={this.addSubTask}>
                <Text style={{ color: 'white' }}>SAVE</Text>

              </TouchableOpacity>
            </View>

          </View>

        </Modal>

      </View>

    );
  }
}

const styles = StyleSheet.create({
  MainContainer:
  {
    flex: 1,
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height
    // width: '90%',
    // paddingLeft: hp('2%'),
  },
  buttonContainer: {
    width: wp('95%'),
    alignSelf: 'baseline',
    marginBottom: 10,
    color: '#d2691e',
    // backgroundColor:'#c0c0c0',
    // justifyContent:'center',
    // alignItems:'center',
    // borderWidth: 0.4,
    // borderRadius: 15,
    marginLeft: 4,
    // shadowOffset : { width: 50, height: 50 },
    // shadowColor: Platform.OS ==='ios' ? null: 'black',
    // shadowOpacity: 9,
    //elevation: 7,

  },
  signupButton: {
    //shadowOpacity: 13,
    //  backgroundColor: '#ffffff',

    // shadowColor: '#141615',

  },
  subcontainer: {
    flex: 2,
    flexDirection: 'row',
    //paddingTop: 40
  },
  signUpText0: {
    fontSize: 14,
    // paddingTop: 20,
    // fontWeight: 'bold',
    color: 'green',
    paddingLeft: 20,
  },
  signUpText1: {
    fontSize: 14,
    // paddingTop: 20,
    // fontWeight: 'bold',
    color: 'green',
    paddingLeft: 23,
  },

  signUpText00: {
    fontSize: 14,
    // paddingTop: 20,
    // fontWeight: 'bold',
    // color: 'green',
    paddingBottom: 5,
    paddingLeft: 20,
  },
  signUpText11: {
    fontSize: 14,
    paddingBottom: 5,
    //  paddingTop: 20,
    // fontWeight: 'bold',
    color: 'black',
    paddingLeft: 23,
  },
  signUpText000: {
    fontSize: 12,
    // paddingTop: 20,
    // fontWeight: 'bold',
    // color: 'green',
    paddingBottom: 5,
    paddingLeft: 20,
  },
  signUpText111: {
    fontSize: 12,
    paddingBottom: 5,
    //  paddingTop: 20,
    // fontWeight: 'bold',
    color: 'black',
    paddingLeft: 23,
  },
  end: {

    alignItems: 'flex-end',

  },
  end1: {
    flex: 1,
    // paddingTop: 20,
    justifyContent: 'space-between',

    flexDirection: 'row',
  },
  s: {
    justifyContent: 'center',

    backgroundColor: '#ed7070',
    shadowOffset: { width: 50, height: 50 },
    alignItems: 'center',
    width: wp('40%'),
    height: hp('12%'),
    borderTopLeftRadius: 10,
    borderBottomLeftRadius: 10,

  },
  signUpText2: {
    fontSize: 14,
    paddingRight: 10,
    //   paddingTop: 20,
    paddingLeft: 23,
    color: 'black',

    // fontWeight: 'bold',
    justifyContent: 'center',

  },
  signUpText02: {
    fontSize: 14,
    paddingRight: 10,
    // paddingTop: 20,
    paddingLeft: 23,
    color: 'blue',
    paddingBottom: 5,
    // fontWeight: 'bold',
    justifyContent: 'center',

  },
  signUpText002: {
    fontSize: 12,
    paddingRight: 10,
    // paddingTop: 20,
    paddingLeft: 23,
    // color: 'red',
    paddingBottom: 5,
    // fontWeight: 'bold',
    justifyContent: 'center',

  },
  signUpText3: {

    paddingBottom: 5,
    paddingLeft: 23,
    fontSize: 14,
    // paddingRight:hp('-10%'),
    paddingRight: 13,
    // fontWeight: 'bold',
    alignItems: 'center',
  },
  signUpText4: {
    paddingBottom: 5,
    paddingLeft: 20,
    // fontWeight: 'bold',
    //color: 'black',
    fontSize: 14,
    alignItems: 'center',
  },


  signUpText33: {

    paddingBottom: 5,
    paddingLeft: 23,
    fontSize: 12,
    // paddingRight:hp('-10%'),
    paddingRight: 13,
    // fontWeight: 'bold',
    paddingTop: -15,
    alignItems: 'center',
  },
  signUpText44: {
    paddingBottom: 5,
    paddingLeft: 20,
    // fontWeight: 'bold',
    paddingTop: -15,
    //color: 'black',
    fontSize: 12,
    alignItems: 'center',
  },

  signup: {
    //paddingTop:20,
    color: "#FFF",
  },
  boxone: {
    flex: 1,
    marginTop: 5,

  },
  boxtwo: {
    flex: 1,

  },
  boxthree: {
    flex: 1,

  },
  box: {
    justifyContent: 'space-between',
    flexDirection: 'row',
    position: 'relative',
    marginBottom: 5,

  },
  box1: {
    justifyContent: 'space-between',
    flexDirection: 'row',
    position: 'relative',
    // marginBottom: 10,

  },
  signUpText: {
    fontSize: 20,
    justifyContent: 'center',


    color: 'white',
    alignSelf: 'center',
  },
  boxheader: {
    justifyContent: 'space-between',
    flexDirection: 'column',
    position: 'relative',
    marginBottom: 5,

  },
});
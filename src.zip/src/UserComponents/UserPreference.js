import React from "react";
import { Text, TouchableOpacity, View,TextInput } from "react-native";


export default class UserPreference extends React.Component{

 render(){

    return(
        <View>

            <TouchableOpacity>

                <Text>UserPreference</Text>
                
                </TouchableOpacity>
        </View>
    );

 }

}
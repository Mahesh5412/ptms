/*
FileName:UserProfile.js
Version:1.0.0
Purpose:Edit and update the profile Description
Devloper:Mahesh
*/
import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Image, StatusBar, Dimensions, TextInput } from 'react-native';
import { Icon, Title, Button, Container, Content, Header, Right, Left, Body, Tab, Tabs, TabHeading, Footer, Item, Input, FooterTab } from 'native-base';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import { TouchableOpacity } from 'react-native-gesture-handler';
import AsyncStorage from '@react-native-community/async-storage';
import { API } from "../WebServices/RestClient";
import NetInfo from '@react-native-community/netinfo';
import Snackbar from 'react-native-snackbar';

export default class UserProfile extends Component {

    constructor(props) {
        super(props);

        this.state = {
            //  fullname: '',
            mobile: '',

        }
    }

    componentDidMount() {
        this.profile();
    }

    //Getting the profile details of User
    profile() {

        AsyncStorage.getItem("cropcode", (err, res) => {
            const cropcode = res;

            AsyncStorage.getItem("empId", (err, res) => {
                const empId = res;
                NetInfo.fetch().then(state => {
                    if (state.type == "none") {
                      console.log(state.type);
                      Snackbar.show({
                        title: 'No Internet Connection',
                        backgroundColor: 'red',
                        duration: Snackbar.LENGTH_LONG,
                      });
                    }else{

                fetch(API + 'getProfile.php', {
                    method: 'POST',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        crop: cropcode,
                        action: "get",
                        //  userType: emp_role,
                        empId: empId
                    })
                }).then((response) => response.json())
                    .then((responseJson) => {
                        console.log(responseJson);
                        console.log(JSON.stringify(responseJson))

                        this.setState({
                            empid: responseJson.data[0].empid,
                            fullName: responseJson.data[0].fullname,
                            team: responseJson.data[0].team,
                            email: responseJson.data[0].email,
                            username: responseJson.data[0].username,
                            mobile: responseJson.data[0].mobile,
                            role: responseJson.data[0].role,
                        },


                            function () {

                            });
                    }).catch((error) => {
                        console.error(error);

                    });
                }
            });
            });

        });
    }

    //Update the User Profile
    save() {

        const { mobile } = this.state;
        console.log(mobile);

        AsyncStorage.getItem("userToken", (err, res) => {
            const empId = res;
            console.log(res);


            AsyncStorage.getItem("cropcode", (err, res) => {
                const cropcode = res;
                console.log(cropcode);
                //alert(res + mobile);
                NetInfo.fetch().then(state => {
                    if (state.type == "none") {
                      console.log(state.type);
                      Snackbar.show({
                        title: 'No Internet Connection',
                        backgroundColor: 'red',
                        duration: Snackbar.LENGTH_LONG,
                      });
                    }else{

                fetch(API + 'getProfile.php', {
                    method: 'POST',
                    headers: {
                        Accept: 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        action: 'update',
                        // idea_id:idea_id, 
                        crop: cropcode,
                        // module_Name:modulename,
                        number: mobile,
                        empId: empId

                    })
                })
                    .then((response) => response.json())
                    .then((responseJson) => {
                        console.log(responseJson)

                        if (responseJson.status == 'True') {


                        } else {
                            alert("user already exist");
                        }

                    })
                    .catch((error) => {
                        console.error(error);
                    });
                }
            });
            });
        });

    }



    render() {
        return (
            <Container>
                <Header
                    androidStatusBarColor="#00A2C1"
                    style={{
                        backgroundColor: '#00A2C1',
                        height: 80,
                        width: Dimensions.get('window').width,
                        borderBottomColor: '#ffffff',
                        justifyContent: 'space-between',
                    }}>
                    <Left>
                        <Icon name="md-menu" style={{ color: '#fff' }} onPress={() =>
                            this.props.navigation.toggleDrawer()} />
                    </Left>
                    <Body>
                        <Title style={{ color: '#fff', fontWeight: '600' }}>Profile</Title>
                    </Body>
                </Header>
<Content>

                <View style={{ padding: 25 }}>
                    <View style={{ justifyContent: 'center', alignItems: 'center', height: hp('25%') }}>
                        <Image source={require('../Images/profile.png')} style={{ width: wp('35%'), height: hp('20%'), margin: 10, borderRadius: 150 / 2, }} />
                        <Text >{this.state.fullName}</Text>
                        {/* <Text>FullName</Text> */}

                    </View>
                    <View style={{ paddingTop: 40, height: hp('50%') }}>
                        <View style={{ flexDirection: 'row', }}>
                            <View style={{ paddingLeft: '2%', width: wp('30%') }}>
                                <Text>Employee ID</Text>

                            </View>
                            <View>
                                <Text>{this.state.empid}</Text>
                            </View>

                        </View>



                        <View style={{ flexDirection: 'row', paddingTop: 10, }}>
                            <View style={{ paddingLeft: '2%', width: wp('30%') }}>
                                <Text>Username</Text>

                            </View>
                            <View>

                                <Text>{this.state.username}</Text>
                            </View>



                        </View>


                        <View style={{ flexDirection: 'row', paddingTop: 10, }}>
                            <View style={{ paddingLeft: '2%', width: wp('30%') }}>
                                <Text>Email</Text>

                            </View>
                            <View>
                                <Text>{this.state.email}</Text>
                            </View>



                        </View>


                        <View style={{ flexDirection: 'row', paddingTop: 10, }}>
                            <View style={{ paddingLeft: '2%', width: wp('30%') }}>
                                <Text>Designation</Text>

                            </View>
                            <View>
                                <Text>developer</Text>
                            </View>



                        </View>

                        <View style={{ flexDirection: 'row', paddingTop: 10, }}>
                            <View style={{ paddingLeft: '2%', width: wp('30%') }}>
                                <Text>Team</Text>

                            </View>
                            <View>
                                <Text>{this.state.team}</Text>
                            </View>



                        </View>

                        <View style={{ flexDirection: 'row', paddingTop: 10, }}>
                            <View style={{ paddingLeft: '2%', width: wp('30%') }}>
                                <Text>Mobile</Text>

                            </View>
                            <View>
                                <TextInput
                                    maxLength={10}
                                    value={this.state.mobile}
                                    onChangeText={(mobile) => this.setState({ mobile })} />

                            </View>



                        </View>

                        <View style={{ flexDirection: 'row', paddingTop: 10, }}>
                            <View style={{ paddingLeft: '2%', width: wp('30%') }}>
                                <Text>Role</Text>

                            </View>
                            <View>
                                <Text>{this.state.role}</Text>
                            </View>



                        </View>

                        <TouchableOpacity onPress={this.save.bind(this)}>
                            <View style={{ paddingTop: 30, paddingLeft: '40%', justifyContent: 'center', alignContent: 'center' }}>
                                <Text style={{ color: '#050404', fontSize: 15 }}>SUBMIT</Text>

                            </View>
                        </TouchableOpacity>
                    </View>



                </View>

                </Content>

            </Container>
        );
    }
}
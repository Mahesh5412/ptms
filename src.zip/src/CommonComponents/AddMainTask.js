/*
FileName:AddMainTask.js
Version:1.0.0
Purpose:Modify the existing module
Devloper:Rishitha,Raju,Naveen,Harsha
*/
import React, { Component } from 'react';
import Requesteddata from '../AdminComponets/AdminRequestedDataProjects';
import { Platform, StyleSheet, Text, View, Dimensions, FlatList, TouchableHighlight, Image, TouchableOpacity, TextInput, Alert, TouchableWithoutFeedback } from 'react-native';
import { Left, Button, Container, Header,Body,Title, Content, Item, Input } from 'native-base';
import AsyncStorage from '@react-native-community/async-storage';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import Modal from "react-native-simple-modal";
import SearchableDropdown from 'react-native-searchable-dropdown';
import Icon from 'react-native-vector-icons/FontAwesome';
import {API }from "../WebServices/RestClient";
import NetInfo from '@react-native-community/netinfo';
import Snackbar from 'react-native-snackbar';

FOOTER_MAX_HEIGHT = 50
FOOTER_MIN_HEIGHT = 40

class ListItem extends React.Component {

  constructor(props) {
    super(props)

    this.state = {

      deletevisibility: false
    }
  }

  componentDidMount() {

    this.VisibleActions();
  }

  async VisibleActions() {

    AsyncStorage.getItem("emp_role", (err, res) => {

      //Alert.alert(res);

      if (res == 'Emp' || res == 'Manager'||res == 'Approver') {

        this.setState({ deletevisibility: true });
      } else {

        this.setState({ deletevisibility: false });
      }

    });

  }



  render() {
    const { item } = this.props;

    let button;

    if (this.state.deletevisibility === false) {
      button =
        <TouchableWithoutFeedback onPress={this.props.DeleteMainTaskAction}>
          <View style={{ width: 55, backgroundColor: 'red', marginRight: 15 }}>
            <Text style={{ color: '#fff', textAlign: 'center' }}>DELETE</Text>
          </View>
        </TouchableWithoutFeedback>;
    } else {
      button = null;
    }

    return (

      <View style={styles.container}>

        <View style={styles.signup}>
          <View style={[styles.buttonContainer, styles.signupButton]} >
            <View style={styles.box}>

              <View style={{ flexDirection: 'row' }}>
                <Text style={styles.signUpText0} >Task No:</Text>
                <Text style={styles.signUpText1} >{item.id}</Text>
              </View>
              <Text style={styles.signUpText2}> {item.assignedDate}</Text>
            </View>
            <View
              style={{
                borderBottomColor: '#C0C0C0',
                borderBottomWidth: 0.3,
              }}
            />

            <View style={{ flexDirection: 'row', paddingRight: 25, }}>
              <Text style={styles.signUpText4} >Title:</Text>
              <Text style={styles.signUpText3} >{item.taskTitle}</Text>
            </View>

            <View style={{ flexDirection: 'row', paddingRight: 25, }}>
              <Text style={styles.signUpText4} >Description:</Text>
              <Text style={styles.signUpText3} >{item.taskDesc}</Text>
            </View>

            <View style={{ flexDirection: 'row', paddingRight: 25, }}>
              <Text style={styles.signUpText4} >Target Time:</Text>
              <Text style={styles.signUpText3} >{item.targetDate}</Text>
              <Text style={styles.listgap} >Task Status:</Text>
              <Text style={styles.signUpText3} >{item.taskStatus}</Text>
            </View>

            <View style={{ flexDirection: 'row', paddingRight: 25, }}>

              <Text style={styles.signUpText4} >Assigned To:</Text>
              <Text style={styles.signUpText3} >{item.toEmp}</Text>
              <Text style={styles.listgap} >Assigned By:</Text>
              <Text style={styles.signUpText3} >{item.byEmp}</Text>
            </View>

            <View style={{ flexDirection: 'row', paddingRight: 25, }}>
              <Text style={styles.signUpText4} >Time Left:</Text>
              <Text style={styles.signUpText3} >{item.timeleft}</Text>
            </View>

            <View style={{ flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center', paddingTop: 15 }}>

              {/* {this.state.deletevisibility === false ?
                <TouchableWithoutFeedback onPress={this.props.DeleteMainTaskAction}>
                  <View style={{ width: 55, backgroundColor: 'red', marginRight: 15 }}>
                    <Text style={{ color: '#fff', textAlign: 'center' }}>DELETE</Text>
                  </View>
                </TouchableWithoutFeedback> : null
              } */}
              {button}


              <TouchableOpacity onPress={this.props.ModifyMaintask} style={{ width: 55, backgroundColor: 'black' }}>
                <Text style={{ color: '#fff', textAlign: 'center' }}>MODIFY</Text></TouchableOpacity>
              <TouchableOpacity onPress={() => this.props.openModal()} style={{ width: 98, backgroundColor: 'green', marginLeft: 10 }}>
                <Text style={{ color: '#fff', textAlign: 'center' }}>ADD SUBTASK</Text></TouchableOpacity>
              <TouchableOpacity onPress={() => this.props.ViewSubTasks()} style={{ width: 100, backgroundColor:'#33adff',
              marginLeft: 10 }}>
                <Text style={{ color: '#fff', textAlign: 'center' }}>VIEWSUBTASK</Text></TouchableOpacity>

            </View>

          </View>

        </View>

      </View>

    )
  }
}

export default class AddMainTask extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      open: false,
      ProjectTitle: "",
      ProjectDescription: "",
      role: '',
      userToken: '',
      isLoading: true,
      dataSource: [],
      isFetching: false,
      modalVisible: false,
      addTask: 'add',
      modifyTask: 'modify',
      moduleId: this.props.navigation.state.params.moduleId,//getting module id
      ideaid: this.props.navigation.state.params.ideaid,//getting idea id
      dependencyid:'NA'
    };
  }


  modalDidOpen = () => {
    AsyncStorage.getItem("role", (err, res) => {
      this.setState({ role: res });

    });
    AsyncStorage.getItem("userToken", (err, res) => {
      this.setState({ userToken: res });

    });

  }

  modalDidClose = () => {

    this.setState({ open: false });
    console.log("Modal did close.");

  };

  //Dialog actions start
  moveUp = () => this.setState({ offset: -100 });

  resetPosition = () => this.setState({ offset: 0 });

  openModal = (item, index) => {
    console.log(item);
    console.log(index);
    this.setState({ item: item }),
      this.setState({ open: true });
  }

  closeModal = () => this.setState({ open: false });
  componentDidMount() {
    this.add();
    this.dependencySearch();
    this.empSearch();
  }
  //Dialog actions end

  //get ModuleList
  add() {

    this.getModulesList();
  }

  onRefresh() {
    this.setState({ isFetching: true }, function () { this.add() });
  }

  componentWillReceiveProps(nextProps) {
    // console.log(nextProps);
    // console.log("re loading...........")
    //this.getModulesList();
  }

  //getModulesList for Projects
  getModulesList() {

    const { moduleId } = this.state;
    const { ideaid } = this.state;

    console.log("moduleid" + moduleId + "ideaid" + ideaid);

    AsyncStorage.getItem("cropcode", (err, res) => {

      const cropcode = res;

      console.log(cropcode)
      console.log(moduleId)
      NetInfo.fetch().then(state => {
        if (state.type == "none") {
          console.log(state.type);
          Snackbar.show({
            title: 'No Internet Connection',
            backgroundColor: 'red',
            duration: Snackbar.LENGTH_LONG,
          });
        }else{
      fetch(API+'get_modulemaintasks.php',
        {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({

            moduleId: moduleId,
            crop: cropcode
          })
        })
        .then((response) => response.json())
        .then((responseJson) => {
          //    alert(JSON.stringify(responseJson));
          console.log(responseJson)
          this.setState({
            isLoading: false,
            dataSource: responseJson.data,
            isFetching: false
          }, function () {

          });
        })
        .catch((error) => {
          console.error(error);
        });
      }
    });
    });

  }

  //Add Subtask for perticular module
  addMainTask = () => {

    const { person, item, dependencyid, subTask, description, days, time, } = this.state;
    console.log(person);
    console.log(dependencyid);
    Alert.alert(dependencyid);
    console.log(subTask);
    console.log(description);
    console.log(item.id);
    // console.log(item.taskid);

    //alert(person+dependencyid);
    let EstHours = Number(days * 24) + Number(time);
    // alert(Number(days)+"  "+Number(time));
    //Employee ID
    AsyncStorage.getItem("empId", (err, res) => {
      const empId = res;
      //crop code
      AsyncStorage.getItem("cropcode", (err, res) => {
        const crop = res;
        NetInfo.fetch().then(state => {
          if (state.type == "none") {
            console.log(state.type);
            Snackbar.show({
              title: 'No Internet Connection',
              backgroundColor: 'red',
              duration: Snackbar.LENGTH_LONG,
            });
          }else{
        fetch(API+'/managesubtasks.php', {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({

            title: subTask,
            description: description,
            days: days,
            EstimatedHours: EstHours,
            assignedBy: empId,
            assignedTo: person,
            dependencyId: this.state.dependencyid,
            action: "add",
            days: this.state.days,
            hours: this.state.time,
            maintaskId: item.id,
            moduleId: item.moduleId,
            empId: empId,
            crop: crop //Async

          })
        }).then((response) => response.json())
          .then((responseJson) => {
            console.log(JSON.stringify(responseJson));
            console.log(responseJson);
            if (responseJson.status === 'True') {
              console.log("done")
              this.setState({ open: false })
            }
          }).catch((error) => {
            console.error(error);
          });
        }
      });
      });
    });
    this.closeModal();
  };

  //Getting the Employees List to assign Subtask start
  empSearch() {
    //crop code
    AsyncStorage.getItem("cropcode", (err, res) => {
      const crop = res;

      fetch(API+'getEmployees.php', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          // proj_title: this.state.ProjectTitle,

          action: "add",
          crop: crop //Async
        })
      })
        .then((response) => response.json())
        .then((responseJson) => {

          this.setState({
            empData: [...responseJson.data],
          });
        }
        )
        .catch((error) => {
          console.error(error);
        });
    });
  }
  //Getting the Employees List to assign Maintask end

  //Getting the Dependency Task List to assign Maintask start
  dependencySearch() {
    //crop code
    AsyncStorage.getItem("cropcode", (err, res) => {
      const crop = res;
      NetInfo.fetch().then(state => {
        if (state.type == "none") {
          console.log(state.type);
          Snackbar.show({
            title: 'No Internet Connection',
            backgroundColor: 'red',
            duration: Snackbar.LENGTH_LONG,
          });
        }else{
      fetch(API+'get_subtasks.php', {
        //fetch('http://115.98.3.215:90/ptmsreact/getEmployees.php')
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          // proj_title: this.state.ProjectTitle,

          action: "setdependency",
          crop: crop //Async
        })
      })
        .then((response) => response.json())
        .then((responseJson) => {

          this.setState({
            dependencyData: [...responseJson.data],
          });
          // AsyncStorage.setItem('userToken',responseJson.name);
        }
        )
        .catch((error) => {
          console.error(error);
        });
      }
    });
    });
  }
  //Getting the Dependency Task List to assign Maintask end

  //Selection of Employee for assign subtask
  // person(item) {
  //   console.log(item);
  //   this.setState({
  //     person: item.name
  //   });
  // }
  // //selection of Dependency name to assign subtask
  // dependency(item) {
  //   console.log(item);
  //   this.setState({
  //     dependency: item.name

  //   });
  //   // AsyncStorage.setItem('',dependency);
  // }


  // Navigaete ViewSubTasks screen
  ViewSubTasks = (item, index) => {
    const { id } = this.state;
    console.log(item.id);
    console.log(index);
    //alert(item.id);
    this.props.navigation.navigate("ViewSubTasks", { taskId: item.id });

  }

  //Modify Maintask start
  ModifyMaintask(item, index) {

    const { moduleId } = this.state;
    const { ideaid } = this.state;
    const { modifyTask } = this.state;
    console.log("moduleid" + moduleId + "ideaid" + ideaid + "action" + modifyTask + "mid" + item.id);

    this.props.navigation.navigate("AddTask", { moduleid: moduleId, IdeaId: ideaid, modifyTask: modifyTask, maintaskid: item.id });

  }
  //Modify Maintask close

  //Delete MainTask alert start
  DeleteMainTaskAction(item, index) {

    Alert.alert(
      'Alert..!',
      'Do you want to delete Task',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        { text: 'OK', onPress: () => this.DeleteMaintask(item.id) },
      ],
      { cancelable: false },
    );

  }
  //Delete MainTask  alert end

  //Delete MainTask start
  DeleteMaintask(maintaskid) {

    AsyncStorage.getItem("cropcode", (err, res) => {
      const cropcode = res;
      NetInfo.fetch().then(state => {
        if (state.type == "none") {
          console.log(state.type);
          Snackbar.show({
            title: 'No Internet Connection',
            backgroundColor: 'red',
            duration: Snackbar.LENGTH_LONG,
          });
        }else{
      fetch(API+'manageMaintasks.php',
        {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({

            action: 'maintaskdelete',
            mainTaskId: maintaskid,
            crop: cropcode
          })
        })
        .then((response) => response.json())
        .then((responseJson) => {
          console.log(responseJson)

          if (responseJson.status === 'True') {

            this.setState({
              isLoading: false,
              isFetching: false
            }, function () {

            });

          } else if (responseJson.status === 'false') {

            Alert.alert(responseJson.message);
          } else {

          }


        })
        .catch((error) => {
          console.error(error);
        });
      }
    });
    });

  }
  //Delete MainTask end


  FlatListItemSeparator = () => {
    return (
      <View
        style={{
          //  height: .5,
          width: "100%",
          backgroundColor: "#000",
        }}
      />
    );
  }



  _listEmptyComponent = () => {
    return (
      <View style={{ width: '90%', height: '80%' }}>
        <Text></Text>
      </View>
    )
  }

  render() {


    return (
      <Container>
      <Header 
        androidStatusBarColor="#00A2C1"
       style={{
      backgroundColor: '#00A2C1', 
      height: 80,
      width: Dimensions.get('window').width, 
      borderBottomColor: '#ffffff',
      justifyContent: 'space-between', 
    }}>
      <Left>
          <Icon size={25} name="arrow-left" style={{color: '#fff'}}onPress={() =>
            this.props.navigation.goBack(null)}  />
          
      </Left>
      <Body>
        <Title style={{color: '#fff', fontWeight: '600' }}>Main Task</Title>
      </Body>
    </Header>
      <View style={styles.MainContainer}>

        <View style={{ height: '96%' }}>

          <FlatList

            extraData={this.state}
            keyExtractor={this._keyExtractor}
            renderItem={this._renderItem}

            data={this.state.dataSource}

            onRefresh={() => this.onRefresh()}
            refreshing={this.state.isFetching}

            ItemSeparatorComponent={this.FlatListItemSeparator}
            renderItem={({ item, index }) =>
              <View>

                <ListItem navigation={this.props.navigation}
                  item={item}
                  ModifyMaintask={() => this.ModifyMaintask(item, index)}//modify maintask
                  openModal={() => this.openModal(item, index)}//add subtask
                  ViewSubTasks={() => this.ViewSubTasks(item, index)}//view subtasks list
                  DeleteMainTaskAction={() => this.DeleteMainTaskAction(item, index)}//delete the maintask
                />
              </View>
            }
            keyExtractor={item => item.id}
            ListEmptyComponent={this._listEmptyComponent}
          />

        </View>
        <Modal animationType="fade" transparent={true} visible={this.state.modalVisible}
          offset={this.state.offset}
          open={this.state.open}
          modalDidOpen={this.modalDidOpen}
          modalDidClose={this.modalDidClose}
          style={{ alignItems: "center", backgroundColor: 'white' }} >


          <View style={{ alignItems: "center", paddingBottom: 60, backgroundColor: 'white' }}>

            <View style={{ marginLeft: 10, width: '100%', backgroundColor: 'white' }}>
              <TextInput placeholder="Sub Task Title" style={{ width: '90%', borderBottomWidth: 0.5 }}
                onChangeText={(text) => this.setState({ subTask: text })}></TextInput>
              <TextInput placeholder="Description" style={{ width: '90%', borderBottomWidth: 0.5 }}
                onChangeText={(text) => this.setState({ description: text })}></TextInput>
            </View>

            <View style={{ marginLeft: 10, width: '100%', }}>
              <Text style={{ paddingTop: 10 }}>Estimated Time</Text>
              <View style={{ flexDirection: 'row', marginTop: 10 }}>
                <TextInput style={{ width: '20%', height: '80%', borderWidth: 0.2 }} onChangeText={(text) =>
                  this.setState({ days: text })}></TextInput>
                <Text style={{ paddingLeft: 10, paddingTop: 10 }}>Days</Text>
                <TextInput style={{ marginLeft: 10, width: '20%', height: '80%', borderWidth: 0.2 }}
                  onChangeText={(text) => this.setState({ time: text })}></TextInput>
                <Text style={{ paddingLeft: 10, paddingTop: 10 }}>Hours</Text>
              </View>
            </View>
            <Text style={{ paddingTop: 10 }}>Select Resources</Text>
            <SearchableDropdown
              onTextChange={text => console.log(text)}

              // onItemSelect={item =>item.name}
              onItemSelect={item => this.setState({ person: item.id })}//assigned employee id getting

              containerStyle={{ padding: 5, color: 'black', }}

              textInputStyle={{
                color: 'black',
                padding: 12,
                borderWidth: 1,
                borderColor: '#ccc',
                // backgroundColor: '#FAF7F6',
                justifyContent: 'center',
                width: wp('85%'),
                // borderRadius:10,

              }}
              itemStyle={{

                padding: 10,
                marginTop: 2,
                // backgroundColor: '#FAF9F8',
                borderColor: '#bbb',
                borderWidth: 1,
                // borderRadius:10,

              }}
              itemTextStyle={{
                color: 'black',
              }}
              itemsContainerStyle={{
                maxHeight: '80%',
              }}
              items={this.state.empData}
              // defaultIndex={2}
              placeholder="          SELECT RESOURCE"

              underlineColorAndroid="transparent"
            />

            <Text style={{ paddingTop: 10 }}>Add Dependency</Text>

            <SearchableDropdown
              onTextChange={text => console.log(text)}

              // onItemSelect={item =>(JSON.stringify(item.name))}
              onItemSelect={(item) => { this.setState({ dependencyid: item.id }) }}//dependency id getting

              containerStyle={{ padding: 5, color: 'black', }}

              textInputStyle={{
                color: 'black',
                padding: 12,
                borderWidth: 1,
                borderColor: '#ccc',
                // backgroundColor: '#FAF7F6',
                justifyContent: 'center',
                width: wp('85%'),
                // borderRadius:10,

              }}
              itemStyle={{

                padding: 10,
                marginTop: 2,
                // backgroundColor: '#FAF9F8',
                borderColor: '#bbb',
                borderWidth: 1,
                // borderRadius:10,

              }}
              itemTextStyle={{
                color: 'black',
              }}
              itemsContainerStyle={{
                maxHeight: '80%',
              }}
              items={this.state.dependencyData}
              //defaultIndex={2}
              // onPress={this.search()}
              placeholder="          ADD DEPENDENCY"

              underlineColorAndroid="transparent"
            />


            <View style={{ flexDirection: 'row', marginTop: 30 }}>
              <TouchableOpacity style={{
                margin: 5, backgroundColor: 'red', padding: 19, height: 30, alignItems:
                  "center", justifyContent: 'center'
              }} onPress={this.closeModal}>
                <Text style={{ color: 'white' }}>CANCEL</Text>
              </TouchableOpacity>
              <TouchableOpacity style={{
                margin: 5, backgroundColor: 'green', padding: 20, height: 30, alignItems:
                  "center", justifyContent: 'center'
              }} onPress={this.addMainTask}>
                <Text style={{ color: 'white' }}>SAVE</Text>

              </TouchableOpacity>
            </View>

          </View>

        </Modal>
        {/* <Modal
          offset={this.state.offset}
          open={this.state.open}
          modalDidOpen={this.modalDidOpen}
          modalDidClose={this.modalDidClose}
          style={{ alignItems: "center" }} >

          <View style={{ alignItems: "center", paddingBottom: 40 }}>

            <Text>Add Module</Text>

            <TextInput placeholder='Module Title'
              style={{ height: 40, borderBottomWidth: 1, borderBottomColor: 'black', width: 300, marginTop: 10 }}
              onChangeText={(text) => this.setState({ text })}
              value={this.state.text} />

            <View style={{ flexDirection: 'row', marginTop: 30 }}>
              <TouchableOpacity style={{
                margin: 5, backgroundColor: 'red', padding: 19, height: 30, alignItems: "center",
                justifyContent: 'center'
              }} onPress={this.closeModal}>
                <Text style={{ color: 'white' }}>CANCEL</Text>
              </TouchableOpacity>
              <TouchableOpacity style={{
                margin: 5, backgroundColor: 'green', padding: 20, height: 30, alignItems: "center",
                justifyContent: 'center'
              }} onPress={this.closeModal}>
                <Text style={{ color: 'white' }}>SAVE</Text>
              </TouchableOpacity>
            </View>

          </View>
        </Modal> */}
        <TouchableOpacity onPress={() => this.props.navigation.navigate("AddTask", { moduleid: this.state.moduleId, IdeaId: this.state.ideaid, addTask: this.state.addTask })} style={styles.bottomView}>
          <View style={styles.bottomView} >
            <Text style={styles.textStyle}>ADD MAINTASK</Text>
          </View>
        </TouchableOpacity>
      </View>
      </Container>

    );

  }

}
const styles = StyleSheet.create(
  {
    MainContainer:
    {
      flex: 1,
      width: Dimensions.get('window').width,
      height: Dimensions.get('window').height
    },
    bottomView: {
      flexDirection: 'row',
      justifyContent: 'center',
      position: 'absolute',
      height: FOOTER_MAX_HEIGHT,
      bottom: 0,
      left: 0,
      right: 0,
      backgroundColor: 'black',
      alignItems: 'center'
    },

    textStyle: {
      color: '#fff',
      fontSize: 18
    },
    container: {
      flex: 1,
      width: '90%',
      paddingLeft: hp('2%'),
    },
    footer: {
      position: 'absolute',
      flex: 0.1,
      left: 0,
      right: 0,
      bottom: -10,
      backgroundColor: 'green',
      flexDirection: 'row',
      height: 80,
      alignItems: 'center',
    },
    bottomButtons: {
      alignItems: 'center',
      justifyContent: 'center',
      flex: 1,
    },
    footerText: {
      color: 'white',
      fontWeight: 'bold',
      alignItems: 'center',
      fontSize: 18,
    },
    buttonContainer: {
      width: wp('90%'),
      alignSelf: 'baseline',
      marginBottom: 10,
      color: '#d2691e',
      marginLeft: 4,



    },
    signupButton: {

      backgroundColor: '#ffffff',
    },
    subcontainer: {
      flex: 2,
      flexDirection: 'row',
      paddingTop: 40
    },
    signUpText0: {
      fontSize: 13,
      color: 'green',
      paddingTop: 10,

    },
    signUpText1: {
      fontSize: 13,
      color: 'green',
      paddingTop: 10,

      paddingLeft: 10,
    },
    end: {

      alignItems: 'flex-end',

    },
    end1: {
      flex: 2,
      height: '50%',
      paddingTop: 20,
      justifyContent: 'space-between',

      flexDirection: 'row',
    },
    s: {
      justifyContent: 'center',

      backgroundColor: '#ed7070',
      shadowOffset: { width: 50, height: 50 },
      alignItems: 'center',
      width: wp('40%'),
      height: hp('12%'),

    },
    signUpText2: {
      fontSize: 10,
      marginLeft: 200,
      fontSize: 13,
      color: 'green',
      paddingTop: 10,

      //  marginRight: 10,
      //textAlign: "right"

    },
    signUpText3: {

      fontSize: 12,
      paddingTop: 10,
      paddingLeft: 10,

      alignItems: 'center',
    },
    signUpText4: {
      fontSize: 12,
      paddingTop: 10,


      alignItems: 'center',
    },
    listgap: {
      fontSize: 12,
      paddingTop: 10,
      paddingLeft: 140,


      alignItems: 'center',
    },
    signup: {
      //paddingTop:20,
      color: "#FFF",

    },
    boxone: {
      flex: 1,
      marginTop: 5,

    },
    boxtwo: {
      flex: 1,

    },
    boxthree: {
      flex: 1,

    },
    box: {
      flexDirection: 'row',
      position: 'relative',
      marginBottom: 10,


    },
    signUpText: {
      fontSize: 20,
      justifyContent: 'center',


      color: 'white',
      alignSelf: 'center',
    },
  });
/*
FileName:ViewSubTasks.js
Version:1.0.0
Purpose:View the subtasks list and also verify subtask
Devloper:Raju,Harsha,Rishitha
*/
import React, { Component } from 'react';
import Requesteddata from '../AdminComponets/AdminRequestedDataProjects';
import { Platform, StyleSheet, Text, View, Dimensions, FlatList, TouchableHighlight, Image, TouchableOpacity, TextInput, Alert } from 'react-native';
import { Left, Button, Container, Header,Body,Title, Content, Item, Input } from 'native-base';
import AsyncStorage from '@react-native-community/async-storage';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import Modal from "react-native-simple-modal";
import RadioGroup from 'react-native-radio-button-group';
import SearchableDropdown from 'react-native-searchable-dropdown';
import Icon from 'react-native-vector-icons/FontAwesome';
import {API }from "../WebServices/RestClient";
import NetInfo from '@react-native-community/netinfo';
import Snackbar from 'react-native-snackbar';

FOOTER_MAX_HEIGHT = 50
FOOTER_MIN_HEIGHT = 40

class ListItem extends React.Component {

  constructor(props) {
    super(props)

    this.state = {

      deletevisibility: false
    }
  }

  componentDidMount() {

    this.VisibleActions();
  }

  async VisibleActions() {

    AsyncStorage.getItem("emp_role", (err, res) => {

      //Alert.alert(res);

      if (res == 'Emp' || res == 'Manager'||res == 'Approver') {

        this.setState({ deletevisibility: true });
      } else {

        this.setState({ deletevisibility: false });
      }

    });

  }

  //Alert for Verify the Subtasks 
  SubtaskVerify() {

    const { item } = this.props;

    Alert.alert(
      'Alert..!',
      'Do you want to Verify Task',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        { text: 'OK', onPress: () => this.SubtaskVerification(item.subTaskId) },
      ],
      { cancelable: false },
    );

  }

  //verifying the subtask start
  SubtaskVerification(subtaskid) {

    AsyncStorage.getItem("cropcode", (err, res) => {
      const cropcode = res;
      NetInfo.fetch().then(state => {
        if (state.type == "none") {
          console.log(state.type);
          Snackbar.show({
            title: 'No Internet Connection',
            backgroundColor: 'red',
            duration: Snackbar.LENGTH_LONG,
          });
        }else{
      fetch(API+'managesubtasks.php',
        {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            crop: cropcode,
            subtaskid: subtaskid,
            action: 'verify'

          })
        })
        .then((response) => response.json())
        .then((responseJson) => {
          if (responseJson.status == 'True') {

          } else if (responseJson.status == 'false') {

            Alert.alert("you can not verify tasks untill subtasks are completed");

          } else { }
        })
        .catch((error) => {
          console.error(error);
        });
      }
    });
    });
  }
  //verifying the subtask close

  render() {
    const { item } = this.props;

    let button;

    if (this.state.deletevisibility === false) {
      button =
      <TouchableOpacity style={{ width: 60, backgroundColor: 'red', marginLeft: 10, }} onPress={this.props.deleteAction}>
      <Text style={{ color: '#fff', textAlign: 'center', }}>DELETE</Text></TouchableOpacity>
    } else {
      button = null;
    }

    return (

      <View style={styles.container}>

        <View style={styles.signup}>

          <View style={[styles.buttonContainer, styles.signupButton]} >

            <View style={styles.box}>

              <View style={{ flexDirection: 'row' }}>
                <Text style={styles.signUpText0} >TASK ID:</Text>
                <Text style={styles.signUpText1} >{item.subTaskId}</Text>
                {/* <Text style={styles.signUpText1} >{item.date}</Text> */}
              </View>
              <Text style={styles.signUpText2} >{item.date}</Text>


            </View>

            <View style={{ flexDirection: 'row', paddingRight: 25, }}>
              <Text style={styles.signUpText4} >Main Task Title:</Text>
              <Text style={styles.signUpText3} >{item.mainTaskTitle}</Text>
              <View style={{ marginLeft: 80 }}
              >
                <RadioGroup
                  horizontal
                  options={[
                    {
                      id: 'ux',
                      labelView: (
                        <Text>
                          <Text style={{ color: 'black' }}>
                          </Text>
                        </Text>
                      ),
                    },

                  ]}
                  //activeButtonId={'user'}
                  circleStyle={{ fillColor: 'black', borderColor: 'black' }}
                //  onChange={(option) => this.setState({usertype: option.id})}
                />
              </View>


            </View>




            <View style={styles.box1}>

              <View style={{ flexDirection: 'row' }}>
                <Text style={styles.signUpText00} >Task Title:</Text>
                <Text style={styles.signUpText11} >{item.taskTitle}</Text>
                {/* <Text style={styles.signUpText1} >{item.date}</Text> */}
              </View>
              <Text style={styles.listgap} >     </Text>
              <TouchableOpacity onPress={() => { this.SubtaskVerify() }}>
                <Text style={styles.signUpText03} >{item.taskstatus}</Text>
              </TouchableOpacity>
            </View>


            <View style={{ flexDirection: 'row', paddingRight: 35, }}>
              <Text style={styles.signUpText44} >Description</Text>
              <Text style={styles.signUpText33} >{item.taskDesc}</Text>
              {/* <Text style={styles.signUpText33} >{item.recipeNames}</Text> */}
            </View>


            <View style={styles.box1}>

              <View style={{ flexDirection: 'row', paddingRight: 35, }}>
                <Text style={styles.signUpText000} >Target Time:</Text>
                <Text style={styles.signUpText111} >{item.targetDate}</Text>
                {/* <Text style={styles.signUpText1} >Task Status:0% completed</Text>  */}
              </View>
              <View styles={{ paddingRight: 40 }}>
                <Text style={styles.signUpText111} >Task Status: </Text>
                <Text style={styles.signUpText111} >{item.taskStatusPercentage}% completed </Text>
              </View>

            </View>
            <View style={styles.box1}>

              <View style={{ flexDirection: 'row' }}>
                <Text style={styles.signUpText000} >Assigned To:</Text>
                <Text style={styles.signUpText111} >{item.assignedTo}</Text>
                {/* <Text style={styles.signUpText1} >{item.date}</Text> */}
              </View>
              <Text style={styles.signUpText002} >Assigned By:</Text>
              <Text style={styles.signUpText111} >{item.assignedBy}</Text>

            </View>

            <View style={{ flexDirection: 'row', paddingRight: 25, }}>
              <Text style={styles.signUpText44} >Assigned On:</Text>
              <Text style={styles.signUpText33} >{item.assignedDate}</Text>
              {/* <Text style={styles.signUpText33} >{item.recipeNames}</Text> */}
            </View>


            <View style={styles.box1}>

              <View style={{ flexDirection: 'row', width: wp('50%'), paddingRight: 50, }}>
                <Text style={styles.signUpText000} >Time Left:</Text>
                <Text style={styles.signUpText111} >{item.timeLeft}</Text>
                {/* <Text style={styles.signUpText1} >{item.date}</Text> */}
              </View>
              <Text style={styles.signUpText000} >Updated On:{item.taskEndDate} </Text>

            </View>

            <View style={{ flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center' }}>
              {/* <TouchableOpacity style={{ width: 120, backgroundColor: '#6cbb3f', marginLeft: 10, }}><Text style={{ color: '#fff', textAlign: 'center' }}>VIEW SUB TASK</Text></TouchableOpacity> */}
              <TouchableOpacity style={{ width: 60, backgroundColor: 'black', marginLeft: 10, }} onPress={() => this.props.openModal()}>
                <Text style={{ color: '#fff', textAlign: 'center', }}>MODIFY</Text></TouchableOpacity>
              {/* <TouchableOpacity style={{ width: 60, backgroundColor: 'red', marginLeft: 10, }} onPress={() => this.props.deleteAction()}>
                <Text style={{ color: '#fff', textAlign: 'center', }}>DELETE</Text></TouchableOpacity> */}
                {button}

            </View>


          </View>

        </View>

      </View>

    )
  }
}

export default class ViewSubTasks extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      open: false,
      ProjectTitle: "",
      ProjectDescription: "",
      role: '',
      userToken: '',
      isLoading: true,
      dataSource: [],
      isFetching: false,
      modalVisible: false,
      taskttitle: '',
      days: '',
      hours: '',
      subTaskId: '',

      //   moduleId:this.props.navigation.state.params.moduleId,
      taskId: this.props.navigation.state.params.taskId,
    };
  }

  modalDidOpen = () => {
    AsyncStorage.getItem("role", (err, res) => {
      this.setState({ role: res });

    });
    AsyncStorage.getItem("userToken", (err, res) => {
      this.setState({ userToken: res });

    });

  }
  modalDidClose = () => {

    this.setState({ open: false });

  };
  //Dialog actions start
  moveUp = () => this.setState({ offset: -1200 });

  resetPosition = () => this.setState({ offset: 0 });

  openModal = (item, index) => {
    const time = item.estimatedHours;
    const days = Number(time / 24);
    const hours = Number(time % 24);
    console.log(item);
    console.log(index);

    this.setState({ days: days, hours: hours })

    console.log(item.taskid);

    this.setState({
      subTask: item.taskTitle,
      description: item.taskDesc,
      person: item.assignedTo,
      name: item.assignedBy,
      // time:item.estimatedHours,
    })
    this.setState({ item: item });
    this.setState({ open: true });
  }
  closeModal = () => this.setState({ open: false });
  //Dialog actions close
  componentDidMount() {
    // alert(this.props.navigation.state.params.taskId)
    this.getSubTasksList();//subtasks list
    this.empSearch();//employees list
    this.dependencySearch();//dependency tasks list
  }

  //refresh subtasktasks list
  onRefresh() {
    this.setState({ isFetching: true }, function () { this.getSubTasksList() });
  }

  componentWillReceiveProps(nextProps) {
    console.log(nextProps);
    console.log("re loading...........")

    this.getSubTasksList();
  }
  //Getting the subtasks list
  getSubTasksList() {
    const { taskId } = this.state;

    //alert("ideaid" + taskId);

    AsyncStorage.getItem("cropcode", (err, res) => {

      const cropcode = res;

      console.log(cropcode)
      NetInfo.fetch().then(state => {
        if (state.type == "none") {
          console.log(state.type);
          Snackbar.show({
            title: 'No Internet Connection',
            backgroundColor: 'red',
            duration: Snackbar.LENGTH_LONG,
          });
        }else{
      fetch(API+'get_subtasks.php',
        {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            crop: cropcode,
            mainTaskId: taskId,
            action: "getsubtasks"
          })
        })
        .then((response) => response.json())
        .then((responseJson) => {
          //alert(JSON.stringify(responseJson));
          console.log(responseJson)
          this.setState({
            isLoading: false,
            dataSource: responseJson.data,
            isFetching: false
          }, function () {

          });
        })
        .catch((error) => {
          console.error(error);
        });
      }
    });
    });
  }
  //Add the subtask start
  addSubTask = () => {

    const { person, item, dependency, subTask, description, days, time, } = this.state;
    console.log(person);
    console.log(dependency);
    console.log(subTask);
    console.log(item);
    console.log(item.taskid);

    let EstHours = Number(days * 24) + Number(time);

    //employee id
    AsyncStorage.getItem("empId", (err, res) => {
      const empId = res;
      //cropcode
      AsyncStorage.getItem("cropcode", (err, res) => {
        const cropcode = res;
        NetInfo.fetch().then(state => {
          if (state.type == "none") {
            console.log(state.type);
            Snackbar.show({
              title: 'No Internet Connection',
              backgroundColor: 'red',
              duration: Snackbar.LENGTH_LONG,
            });
          }else{
        fetch(API+'managesubtasks.php', {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({

            title: subTask,
            description: description,
            days: days,
            assignedBy: empId,
            assignedTo: person,
            dependencyId: this.state.dependencyid,
            action: "modify",
            days: this.state.days,
            hours: this.state.time,
            subtaskid: item.subTaskId,
            empId: empId,
            crop: cropcode,

          })
        }).then((response) => response.json())
          .then((responseJson) => {
            // alert(JSON.stringify(responseJson));
            console.log(days);
            console.log(description);
            console.log(person);
            console.log(responseJson);
            if (responseJson.status === 'true') {
              console.log("done")
              this.setState({ open: false })
            } else {
              alert("task not modified");
            }
          }).catch((error) => {
            console.error(error);
          });
        }
      });
      });
    });
    this.closeModal();
  };
  //Add the subtask end

  //Getting Employees List start
  empSearch() {
    AsyncStorage.getItem("cropcode", (err, res) => {
      const crop = res;
      NetInfo.fetch().then(state => {
        if (state.type == "none") {
          console.log(state.type);
          Snackbar.show({
            title: 'No Internet Connection',
            backgroundColor: 'red',
            duration: Snackbar.LENGTH_LONG,
          });
        }else{
      fetch(API+'getEmployees.php', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: "add",
          crop: crop //Async
        })
      })
        .then((response) => response.json())
        .then((responseJson) => {

          this.setState({
            empData: [...responseJson.data],
          });
        }
        )
        .catch((error) => {
          console.error(error);
        });
      }
    });
    });
  }
  //Getting Employees List end

  //Getting dependency task list start
  dependencySearch() {
    AsyncStorage.getItem("cropcode", (err, res) => {
      const crop = res;
      NetInfo.fetch().then(state => {
        if (state.type == "none") {
          console.log(state.type);
          Snackbar.show({
            title: 'No Internet Connection',
            backgroundColor: 'red',
            duration: Snackbar.LENGTH_LONG,
          });
        }else{
      fetch(API+'get_subtasks.php', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: "setdependency",
          crop: crop //Async
        })
      })
        .then((response) => response.json())
        .then((responseJson) => {

          this.setState({
            dependencyData: [...responseJson.data],
          });
        }
        )
        .catch((error) => {
          console.error(error);
        });
      }
    });
    });
  }
  //Getting dependency task list end



  FlatListItemSeparator = () => {
    return (
      <View
        style={{
          //  height: .5,
          width: "100%",
          backgroundColor: "red",
        }}
      />
    );
  }
  //employee id getting
  person(item) {
    console.log(item);
    this.setState({
      person: item.name
    });
  }
  //dependecy id getting for task
  dependency(item) {
    console.log(item);
    this.setState({
      dependency: item.name

    });
    // AsyncStorage.setItem('',dependency);
  }

  //delete alert for subtask start
  deleteAction(item, index){
    Alert.alert(
      'Alert..!',
      'Do you want to delete Subtask',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        { text: 'OK', onPress: () => this.deleteSubtask(item) },
      ],
      { cancelable: false },
    );
  }
  //delete alert for subtask end

  //Delete Subtask strat
  deleteSubtask = (item) => {
    AsyncStorage.getItem("cropcode", (err, res) => {
      const crop = res;
      NetInfo.fetch().then(state => {
        if (state.type == "none") {
          console.log(state.type);
          Snackbar.show({
            title: 'No Internet Connection',
            backgroundColor: 'red',
            duration: Snackbar.LENGTH_LONG,
          });
        }else{
      fetch(API+'managesubtasks.php', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({


          subtaskid: item.subTaskId,
          action: "deletesubtask",
          crop: crop, //Async
        })
      }).then((response) => response.json())
        .then((responseJson) => {
          console.log(JSON.stringify(responseJson));

          console.log(responseJson);
          if (responseJson.status === 'true') {
            console.log("done")
            this.setState({ open: false })
            // this.props.navigation.navigate('AdminManageProjects');
          }
        }).catch((error) => {
          console.error(error);
        });
      }
    });
    });
  };
  //delete Subtask end

  _listEmptyComponent = () => {
    return (
      <View>
        <Text></Text>

      </View>
    )
  }

  render() {


    return (
      <Container>
      <Header 
        androidStatusBarColor="#00A2C1"
       style={{
      backgroundColor: '#00A2C1', 
      height: 80,
      width: Dimensions.get('window').width, 
      borderBottomColor: '#ffffff',
      justifyContent: 'space-between', 
    }}>
      <Left>
          <Icon size={25} name="arrow-left" style={{color: '#fff'}}onPress={() =>
            this.props.navigation.goBack(null)}  />
          
      </Left>
      <Body>
        <Title style={{color: '#fff', fontWeight: '600' }}>Sub Task</Title>
      </Body>
    </Header>
      <View style={styles.MainContainer}>

        <View style={{ height: '96%' }}>

          <FlatList

            extraData={this.state}
            keyExtractor={this._keyExtractor}
            renderItem={this._renderItem}

            data={this.state.dataSource}

            onRefresh={() => this.onRefresh()}
            refreshing={this.state.isFetching}

            ItemSeparatorComponent={this.FlatListItemSeparator}
            renderItem={({ item, index }) =>
              <View>

                <ListItem navigation={this.props.navigation}
                  item={item}
                  Module={() => this.Module(item, index)}
                  openModal={() => this.openModal(item, index)}//Add Subtask
                  deleteAction={()=>this.deleteAction(item, index)}//Delete Subtask
                />
              </View>
            }
            keyExtractor={item => item.id}
            ListEmptyComponent={this._listEmptyComponent}
          />

        </View>

        <Modal
          offset={this.state.offset}
          open={this.state.open}
          modalDidOpen={this.modalDidOpen}
          modalDidClose={this.modalDidClose}
          style={{ alignItems: "center", backgroundColor: 'white' }} >
          <View style={{ alignItems: "center", paddingBottom: 60, backgroundColor: 'white' }}>

            <View style={{ marginLeft: 10, width: '100%', backgroundColor: 'white' }}>
              <TextInput placeholder="Sub Task Title" style={{ width: '90%', borderBottomWidth: 0.5 }}
                value={this.state.subTask}
                onChangeText={(text) => this.setState({ subTask: text })}></TextInput>
              <TextInput placeholder="Description" style={{ width: '90%', borderBottomWidth: 0.5 }}
                value={this.state.description}
                onChangeText={(text) => this.setState({ description: text })}></TextInput>
            </View>

            <View style={{ marginLeft: 10, width: '100%', }}>
              <Text style={{ paddingTop: 10 }}>Estimated Time</Text>
              <View style={{ flexDirection: 'row', marginTop: 10 }}>
                <TextInput style={{ width: '20%', height: '80%', borderWidth: 0.2 }}
                  value={this.state.days}
                  onChangeText={(text) => this.setState({ days: text })}></TextInput>
                <Text style={{ paddingLeft: 10, paddingTop: 10 }}>Days</Text>
                <TextInput style={{ marginLeft: 10, width: '20%', height: '80%', borderWidth: 0.2 }}
                  value={this.state.hours}
                  onChangeText={(text) => this.setState({ time: text })}></TextInput>
                <Text style={{ paddingLeft: 10, paddingTop: 10 }}>Hours</Text>
              </View>
            </View>
            <Text style={{ paddingTop: 10 }}>Select Resources</Text>
            <SearchableDropdown
              onTextChange={text => console.log(text)}
              value={this.state.name}
              // onItemSelect={item =>item.name}
              onItemSelect={item => this.setState({ person: item.id })}

              containerStyle={{ padding: 5, color: 'black', }}

              textInputStyle={{
                color: 'black',
                padding: 12,
                borderWidth: 1,
                borderColor: '#ccc',
                // backgroundColor: '#FAF7F6',
                justifyContent: 'center',
                width: wp('85%'),
                // borderRadius:10,

              }}
              itemStyle={{

                padding: 10,
                marginTop: 2,
                // backgroundColor: '#FAF9F8',
                borderColor: '#bbb',
                borderWidth: 1,
                // borderRadius:10,

              }}
              itemTextStyle={{
                color: 'black',
              }}
              itemsContainerStyle={{
                maxHeight: '80%',
              }}
              items={this.state.empData}

              // defaultIndex={1}
              placeholder="          SELECT RESOURCE"

              underlineColorAndroid="transparent"
            />

            <Text style={{ paddingTop: 10 }}>Add Dependency</Text>

            <SearchableDropdown

              onTextChange={text => console.log(text)}
              // onItemSelect={item =>(JSON.stringify(item.name))}
              onItemSelect={(item) => { this.setState({ dependencyid: item.id }) }}

              containerStyle={{ padding: 5, color: 'black', }}

              textInputStyle={{
                color: 'black',
                padding: 12,
                borderWidth: 1,
                borderColor: '#ccc',
                // backgroundColor: '#FAF7F6',
                justifyContent: 'center',
                width: wp('85%'),
                // borderRadius:10,

              }}
              itemStyle={{

                padding: 10,
                marginTop: 2,
                // backgroundColor: '#FAF9F8',
                borderColor: '#bbb',
                borderWidth: 1,
                // borderRadius:10,

              }}
              itemTextStyle={{
                color: 'black',
              }}
              itemsContainerStyle={{
                maxHeight: '80%',
              }}
              value={this.state.subTask}
              items={this.state.dependencyData}
              // defaultIndex={1}

              placeholder="          ADD DEPENDENCY"

              underlineColorAndroid="transparent"
            />


            <View style={{ flexDirection: 'row', marginTop: 30 }}>
              <TouchableOpacity style={{
                margin: 5, backgroundColor: 'red', padding: 19, height: 30, alignItems:
                  "center", justifyContent: 'center'
              }} onPress={this.closeModal}>
                <Text style={{ color: 'white' }}>CANCEL</Text>
              </TouchableOpacity>
              <TouchableOpacity style={{
                margin: 5, backgroundColor: 'green', padding: 20, height: 30, alignItems:
                  "center", justifyContent: 'center'
              }} onPress={this.addSubTask}>
                <Text style={{ color: 'white' }}>SAVE</Text>

              </TouchableOpacity>
            </View>

          </View>

        </Modal>


      </View>
      </Container>

    );

  }

}
const styles = StyleSheet.create({
  MainContainer:
  {
    flex: 1,
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height
    // width: '90%',
    // paddingLeft: hp('2%'),
  },
  buttonContainer: {
    width: wp('95%'),
    alignSelf: 'baseline',
    marginBottom: 10,
    color: '#d2691e',
    // backgroundColor:'#c0c0c0',
    // justifyContent:'center',
    // alignItems:'center',
    // borderWidth: 0.4,
    // borderRadius: 15,
    marginLeft: 4,
    // shadowOffset : { width: 50, height: 50 },
    // shadowColor: Platform.OS ==='ios' ? null: 'black',
    // shadowOpacity: 9,
    //elevation: 7,

  },
  signupButton: {
    //shadowOpacity: 13,
    //  backgroundColor: '#ffffff',

    // shadowColor: '#141615',

  },
  subcontainer: {
    flex: 2,
    flexDirection: 'row',
    //paddingTop: 40
  },
  signUpText0: {
    fontSize: 14,
    // paddingTop: 20,
    // fontWeight: 'bold',
    color: 'green',
    paddingLeft: 20,
  },
  signUpText1: {
    fontSize: 14,
    // paddingTop: 20,
    // fontWeight: 'bold',
    color: 'green',
    paddingLeft: 23,
  },

  signUpText00: {
    fontSize: 14,
    // paddingTop: 20,
    // fontWeight: 'bold',
    // color: 'green',
    paddingBottom: 5,
    paddingLeft: 20,
  },
  signUpText11: {
    fontSize: 14,
    paddingBottom: 5,
    //  paddingTop: 20,
    width: wp('60%'),
        color: 'black',
    paddingLeft: 23,
  },
  signUpText000: {
    fontSize: 12,
    // paddingTop: 20,
    // fontWeight: 'bold',
    // color: 'green',
    paddingBottom: 5,
    paddingLeft: 20,
  },
  textStyle: {

    color: '#fff',
    fontSize: 22
  },
  signUpText111: {
    fontSize: 12,
    paddingBottom: 5,
    //  paddingTop: 20,
    // fontWeight: 'bold',
    color: 'black',
    paddingLeft: 23,
  },
  end: {

    alignItems: 'flex-end',

  },
  end1: {
    flex: 1,
    // paddingTop: 20,
    justifyContent: 'space-between',

    flexDirection: 'row',
  },
  s: {
    justifyContent: 'center',

    backgroundColor: '#ed7070',
    shadowOffset: { width: 50, height: 50 },
    alignItems: 'center',
    width: wp('40%'),
    height: hp('12%'),
    borderTopLeftRadius: 10,
    borderBottomLeftRadius: 10,

  },
  signUpText2: {
    fontSize: 14,
    paddingRight: 10,
    //   paddingTop: 20,
    paddingLeft: 23,
    color: 'black',

    // fontWeight: 'bold',
    justifyContent: 'center',

  },
  signUpText02: {
    fontSize: 14,
    paddingRight: 10,
    // paddingTop: 20,
    paddingLeft: 23,
    color: 'blue',
    paddingBottom: 5,
    // fontWeight: 'bold',
    justifyContent: 'center',

  },
  signUpText002: {
    fontSize: 12,
    paddingRight: 10,
    // paddingTop: 20,
    paddingLeft: 23,
    // color: 'red',
    paddingBottom: 5,
    // fontWeight: 'bold',
    justifyContent: 'center',

  },
  bottomView: {
    flexDirection: 'row',
    justifyContent: 'center',
    position: 'absolute',
    height: FOOTER_MAX_HEIGHT,
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'black',
    alignItems: 'center'
  },

  signUpText3: {

    paddingBottom: 5,
    paddingLeft: 23,
    fontSize: 14,
    width: wp('90%') ,
        paddingRight: 13,
    // fontWeight: 'bold',
    alignItems: 'center',
    width: wp('40%'),
  },
  signUpText4: {
    paddingBottom: 5,
    paddingLeft: 20,
    // fontWeight: 'bold',
    //color: 'black',
    fontSize: 14,
    alignItems: 'center',
  },


  signUpText33: {

    paddingBottom: 5,
    paddingLeft: 23,
    fontSize: 12,
    // paddingRight:hp('-10%'),
    paddingRight: 13,
    // fontWeight: 'bold',
    paddingTop: -15,
    alignItems: 'center',
  },
  signUpText44: {
    paddingBottom: 5,
    paddingLeft: 20,
    // fontWeight: 'bold',
    paddingTop: -15,
    //color: 'black',
    fontSize: 12,
    alignItems: 'center',
  },

  signup: {
    //paddingTop:20,
    color: "#FFF",
  },
  boxone: {
    flex: 1,
    marginTop: 5,

  },
  boxtwo: {
    flex: 1,

  },
  boxthree: {
    flex: 1,

  },
  box: {
    justifyContent: 'space-between',
    flexDirection: 'row',
    position: 'relative',
    marginBottom: 5,

  },
  box1: {
    justifyContent: 'space-between',
    flexDirection: 'row',
    position: 'relative',
    // marginBottom: 10,

  },
  signUpText: {
    fontSize: 20,
    justifyContent: 'center',


    color: 'white',
    alignSelf: 'center',
  },
  signUpText03: {

    fontSize: 12,
    color: 'blue',
    paddingLeft: 10,
    alignSelf: 'flex-end',


    alignItems: 'center',
  },
});